package domain;

import jpa.Role;

/**
 * Created by Nahid on 2017-03-23.
 */
public class UsersDomain {
    private int id;
    private String firstName;
    private String lastName;
    private String userName;
    private String password;
    private Role role;


}
