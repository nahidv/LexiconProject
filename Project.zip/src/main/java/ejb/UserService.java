package ejb;

/**
 * Created by Nahid on 2017-03-28.
 */
public class UserService {
}
